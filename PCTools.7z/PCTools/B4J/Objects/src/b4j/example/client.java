package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class client extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.client", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.client.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.example.servermanager _mmanager = null;
public anywheresoftware.b4a.objects.SocketWrapper _socket1 = null;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public boolean _connected = false;
public String _id = "";
public b4j.example.main _main = null;
public b4j.example.utils _utils = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _astream_error() throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Sub AStream_Error";
 //BA.debugLineNum = 25;BA.debugLine="mManager.ClientDisconnected(Me)";
_mmanager._clientdisconnected /*String*/ ((b4j.example.client)(this));
 //BA.debugLineNum = 27;BA.debugLine="UpdateState(False)	'UI介面 更新狀態";
_updatestate(__c.False);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public String  _astream_newdata(byte[] _buffer) throws Exception{
b4j.example.b4xmainpage _p = null;
 //BA.debugLineNum = 38;BA.debugLine="Sub AStream_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 41;BA.debugLine="Dim p As B4XMainPage = B4XPages.GetPage(\"MainPage";
_p = (b4j.example.b4xmainpage)(_b4xpages._getpage /*Object*/ ("MainPage"));
 //BA.debugLineNum = 42;BA.debugLine="p.NewData(Buffer)";
_p._newdata /*String*/ (_buffer);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _astream_terminated() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Sub AStream_Terminated";
 //BA.debugLineNum = 32;BA.debugLine="mManager.ClientDisconnected(Me)";
_mmanager._clientdisconnected /*String*/ ((b4j.example.client)(this));
 //BA.debugLineNum = 34;BA.debugLine="UpdateState(False)	'UI介面 更新狀態";
_updatestate(__c.False);
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private mManager As ServerManager";
_mmanager = new b4j.example.servermanager();
 //BA.debugLineNum = 5;BA.debugLine="Public socket1 As Socket			'jNetwork lib.客戶端 sock";
_socket1 = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 6;BA.debugLine="Private astream As AsyncStreams		'jRandomAccessFi";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 8;BA.debugLine="Public connected As Boolean			'連線狀態.True連線中.False";
_connected = false;
 //BA.debugLineNum = 9;BA.debugLine="Public Id As String			'給每個連線端一個隨機編號";
_id = "";
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.SocketWrapper _newsocket,b4j.example.servermanager _manager) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 14;BA.debugLine="Public Sub Initialize(NewSocket As Socket, manager";
 //BA.debugLineNum = 15;BA.debugLine="Id = Utils.RandomString(10)	'隨機給一個身分.我不知道這函數是否會重複";
_id = _utils._randomstring /*String*/ ((int) (10));
 //BA.debugLineNum = 17;BA.debugLine="mManager = manager";
_mmanager = _manager;
 //BA.debugLineNum = 18;BA.debugLine="socket1 = NewSocket";
_socket1 = _newsocket;
 //BA.debugLineNum = 19;BA.debugLine="astream.InitializePrefix(NewSocket.InputStream, F";
_astream.InitializePrefix(ba,_newsocket.getInputStream(),__c.False,_newsocket.getOutputStream(),"astream");
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _senddata(byte[] _data) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Public Sub SendData (data() As Byte)";
 //BA.debugLineNum = 53;BA.debugLine="astream.Write(data)";
_astream.Write(_data);
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public String  _updatestate(boolean _newstate) throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub UpdateState (NewState As Boolean)";
 //BA.debugLineNum = 59;BA.debugLine="connected = NewState";
_connected = _newstate;
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
