package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class udpconnect2 extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.udpconnect2", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.udpconnect2.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.SocketWrapper.UDPSocket _udpsock = null;
public anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _sockserver = null;
public anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
public int _port = 0;
public b4j.example.main _main = null;
public b4j.example.utils _utils = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private udpsock As UDPSocket";
_udpsock = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket();
 //BA.debugLineNum = 3;BA.debugLine="Private sockServer As ServerSocket 'ignore";
_sockserver = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 5;BA.debugLine="Private bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 6;BA.debugLine="Public const port As Int = 9002";
_port = (int) (9002);
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 12;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 13;BA.debugLine="udpsock.Initialize(\"udpsock\", port, 8192)		'port=";
_udpsock.Initialize(ba,"udpsock",_port,(int) (8192));
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public String  _udpsock_packetarrived(anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket _packet) throws Exception{
byte[] _data = null;
String _s = "";
b4j.example.b4xmainpage _p = null;
 //BA.debugLineNum = 21;BA.debugLine="Sub udpsock_PacketArrived (Packet As UDPPacket)";
 //BA.debugLineNum = 22;BA.debugLine="Try";
try { //BA.debugLineNum = 24;BA.debugLine="Dim data() As Byte = Packet.Data";
_data = _packet.getData();
 //BA.debugLineNum = 25;BA.debugLine="If Packet.Data.Length > Packet.Length Then";
if (_packet.getData().length>_packet.getLength()) { 
 //BA.debugLineNum = 26;BA.debugLine="Dim data(Packet.Length) As Byte";
_data = new byte[_packet.getLength()];
;
 //BA.debugLineNum = 27;BA.debugLine="bc.ArrayCopy(Packet.Data, 0, data, 0, Packet.Le";
_bc.ArrayCopy((Object)(_packet.getData()),(int) (0),(Object)(_data),(int) (0),_packet.getLength());
 };
 //BA.debugLineNum = 31;BA.debugLine="Log(BytesToString(data,0,data.Length,\"UTF8\"))";
__c.LogImpl("62031626",__c.BytesToString(_data,(int) (0),_data.length,"UTF8"),0);
 //BA.debugLineNum = 33;BA.debugLine="Dim s As String = BytesToString(data,0,data.Leng";
_s = __c.BytesToString(_data,(int) (0),_data.length,"UTF8");
 //BA.debugLineNum = 34;BA.debugLine="If s =\"LED1\" Then";
if ((_s).equals("LED1")) { 
 //BA.debugLineNum = 35;BA.debugLine="Dim p As B4XMainPage = B4XPages.GetPage(\"MainPa";
_p = (b4j.example.b4xmainpage)(_b4xpages._getpage /*Object*/ ("MainPage"));
 //BA.debugLineNum = 37;BA.debugLine="p.LED1";
_p._led1 /*String*/ ();
 };
 //BA.debugLineNum = 39;BA.debugLine="If s =\"LED2\" Then";
if ((_s).equals("LED2")) { 
 //BA.debugLineNum = 40;BA.debugLine="Dim p As B4XMainPage = B4XPages.GetPage(\"MainPa";
_p = (b4j.example.b4xmainpage)(_b4xpages._getpage /*Object*/ ("MainPage"));
 //BA.debugLineNum = 42;BA.debugLine="p.LED2";
_p._led2 /*String*/ ();
 };
 } 
       catch (Exception e18) {
			ba.setLastException(e18); //BA.debugLineNum = 54;BA.debugLine="Log(LastException)";
__c.LogImpl("62031649",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
