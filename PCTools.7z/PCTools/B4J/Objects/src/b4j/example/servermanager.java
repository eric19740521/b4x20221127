package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class servermanager extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.servermanager", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.servermanager.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public anywheresoftware.b4a.objects.collections.List _clients = null;
public b4j.example.main _main = null;
public b4j.example.utils _utils = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Public server As ServerSocket		'jNetwork lib.服務器端";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 4;BA.debugLine="Public clients As List";
_clients = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
public String  _clientdisconnected(b4j.example.client _client1) throws Exception{
int _i = 0;
 //BA.debugLineNum = 49;BA.debugLine="Public Sub ClientDisconnected (client1 As Client)";
 //BA.debugLineNum = 50;BA.debugLine="Dim i As Int = clients.IndexOf(client1)";
_i = _clients.IndexOf((Object)(_client1));
 //BA.debugLineNum = 51;BA.debugLine="If i > -1 Then clients.RemoveAt(i)";
if (_i>-1) { 
_clients.RemoveAt(_i);};
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public String  _getip() throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="public Sub GetIP As String";
 //BA.debugLineNum = 41;BA.debugLine="Return server.GetMyIP";
if (true) return _server.GetMyIP();
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public int  _getnumberofclients() throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Public Sub getNumberOfClients As Int";
 //BA.debugLineNum = 46;BA.debugLine="Return clients.Size";
if (true) return _clients.getSize();
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,int _port1) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 10;BA.debugLine="Public Sub Initialize(port1 As Int)";
 //BA.debugLineNum = 13;BA.debugLine="clients.Initialize						'client清單 初始化";
_clients.Initialize();
 //BA.debugLineNum = 14;BA.debugLine="server.Initialize(port1, \"server\")		'server物件 初始化";
_server.Initialize(ba,_port1,"server");
 //BA.debugLineNum = 16;BA.debugLine="server.Listen							'server正在聆聽";
_server.Listen();
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _sendall(byte[] _data,String _id) throws Exception{
int _i = 0;
b4j.example.client _c = null;
 //BA.debugLineNum = 58;BA.debugLine="Public Sub SendALL(data() As Byte,Id As String)";
 //BA.debugLineNum = 60;BA.debugLine="For i = 0 To clients.Size - 1";
{
final int step1 = 1;
final int limit1 = (int) (_clients.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit1 ;_i = _i + step1 ) {
 //BA.debugLineNum = 61;BA.debugLine="Dim c As Client";
_c = new b4j.example.client();
 //BA.debugLineNum = 62;BA.debugLine="c = clients.Get(i)";
_c = (b4j.example.client)(_clients.Get(_i));
 //BA.debugLineNum = 64;BA.debugLine="If Id <> c.Id Then";
if ((_id).equals(_c._id /*String*/ ) == false) { 
 //BA.debugLineNum = 66;BA.debugLine="c.SendData(data)		'送給給連線端的人";
_c._senddata /*String*/ (_data);
 };
 }
};
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
b4j.example.client _c = null;
 //BA.debugLineNum = 21;BA.debugLine="Sub server_NewConnection (Successful As Boolean, N";
 //BA.debugLineNum = 22;BA.debugLine="Log(\"New connection\")";
__c.LogImpl("62686977","New connection",0);
 //BA.debugLineNum = 24;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 26;BA.debugLine="Dim c As Client";
_c = new b4j.example.client();
 //BA.debugLineNum = 27;BA.debugLine="c.Initialize(NewSocket, Me)";
_c._initialize /*String*/ (ba,_newsocket,(b4j.example.servermanager)(this));
 //BA.debugLineNum = 28;BA.debugLine="clients.Add(c)";
_clients.Add((Object)(_c));
 };
 //BA.debugLineNum = 33;BA.debugLine="server.Listen";
_server.Listen();
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
