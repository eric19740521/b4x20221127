package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class commandhandler extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.commandhandler", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.commandhandler.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.objects.JFX _fx = null;
public butt.droid.awtRobot.AWTRobot _rbt = null;
public anywheresoftware.b4j.object.JavaObject _rbtjo = null;
public b4j.example.main _main = null;
public b4j.example.utils _utils = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 5;BA.debugLine="Private rbt As AWTRobot";
_rbt = new butt.droid.awtRobot.AWTRobot();
 //BA.debugLineNum = 6;BA.debugLine="Private rbtJO As JavaObject = rbt";
_rbtjo = new anywheresoftware.b4j.object.JavaObject();
_rbtjo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_rbt));
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
public String  _handlecommand(b4j.example.main._remotecommand _rc) throws Exception{
 //BA.debugLineNum = 14;BA.debugLine="Public Sub HandleCommand(rc As RemoteCommand)";
 //BA.debugLineNum = 21;BA.debugLine="If rc.Command = \"PCControls\" Then";
if ((_rc.Command /*String*/ ).equals("PCControls")) { 
 //BA.debugLineNum = 22;BA.debugLine="rbtJO.RunMethod(rc.Method, rc.Args)";
_rbtjo.RunMethod(_rc.Method /*String*/ ,_rc.Args /*Object[]*/ );
 };
 //BA.debugLineNum = 24;BA.debugLine="If rc.Command = \"SendMsg\" Then";
if ((_rc.Command /*String*/ ).equals("SendMsg")) { 
 //BA.debugLineNum = 25;BA.debugLine="rbt.RobotPaste(rc.Method)";
_rbt.RobotPaste(_rc.Method /*String*/ );
 };
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 9;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
